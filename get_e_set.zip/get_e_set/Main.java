import java.util.Scanner;

public class Main{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        //Menu de opcões
        System.out.println("Escolha o que deseja fazer");
        System.out.println("1-Cadastrar");
        System.out.println("2-Editar");
        System.out.println("3-Apresentar");
        System.out.println("4-Excluir");
        System.out.println("Digite o número da tarefa que deseja realizar");
        String opcao = scanner.nextLine();

        switch(opcao){
            case 1:
            System.out.println("Cadastro de pessoa");
        }
    }
}